<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Tell the browser to be responsive to screen width -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap 4 -->
<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="assets/vendor/fontawesome-free/css/all.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="assets/vendor/adminlte/adminlte.min.css">
<!-- overlayScrollbars -->
<link rel="stylesheet" href="assets/vendor/overlayScrollbars/css/OverlayScrollbars.min.css">
<!-- datatables -->
<link rel="stylesheet" href="assets/vendor/datatables/css/dataTables.bootstrap4.min.css">
<!-- fancybox -->
<link rel="stylesheet" href="assets/vendor/fancybox/jquery.fancybox.min.css">
<!-- Google Font: Source Sans Pro -->
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
<!-- Favicon -->
<link rel="icon" href="assets/img/img_properties/um.png">