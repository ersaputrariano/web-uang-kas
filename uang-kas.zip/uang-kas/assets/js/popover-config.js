$(document).ready(function() {
    $(function () {
        $('[data-toggle="popover"]').popover();
    });
});